-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: attendance_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_manual_attendance`
--

DROP TABLE IF EXISTS `admin_manual_attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_manual_attendance` (
  `id` char(36) NOT NULL,
  `employee_id` char(36) NOT NULL,
  `attendance_date` date NOT NULL,
  `time_in` datetime DEFAULT NULL,
  `time_out` datetime DEFAULT NULL,
  `attendance_status` enum('present','absent','half_day','holiday','leave') NOT NULL DEFAULT 'present',
  `method` enum('Manual Entry','PIN','QR Code','RFID','System Generated') NOT NULL DEFAULT 'Manual Entry',
  `reason` text NOT NULL,
  `admin_remarks` text DEFAULT NULL,
  `created_by` char(36) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ama_employee` (`employee_id`),
  KEY `idx_ama_date` (`attendance_date`),
  KEY `idx_ama_created_by` (`created_by`),
  CONSTRAINT `fk_ama_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_ama_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_manual_attendance`
--

LOCK TABLES `admin_manual_attendance` WRITE;
/*!40000 ALTER TABLE `admin_manual_attendance` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_manual_attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` char(36) NOT NULL,
  `title` varchar(200) NOT NULL,
  `body` text NOT NULL,
  `author_id` char(36) DEFAULT NULL,
  `branch_id` char(36) DEFAULT NULL COMMENT 'NULL = all branches',
  `target_type` enum('all','department','employee') NOT NULL DEFAULT 'all',
  `target_id` char(36) DEFAULT NULL COMMENT 'department_id or employee_id',
  `pinned` tinyint(1) NOT NULL DEFAULT 0,
  `publish_at` datetime DEFAULT NULL,
  `expire_at` datetime DEFAULT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `status` enum('draft','published','archived') NOT NULL DEFAULT 'draft',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_announcements_status` (`status`),
  KEY `idx_announcements_branch` (`branch_id`),
  KEY `idx_announcements_publish` (`publish_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendance` (
  `id` char(36) NOT NULL,
  `employee_id` char(36) NOT NULL,
  `attendance_date` date NOT NULL,
  `time_recorded` datetime NOT NULL,
  `attendance_type` enum('time_in','break_out','break_in','time_out','overtime_in','overtime_out','lunch_out','lunch_in') NOT NULL,
  `method` enum('pin','qr_code','rfid','manual') NOT NULL DEFAULT 'pin',
  `device_name` varchar(100) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `is_late` tinyint(1) NOT NULL DEFAULT 0,
  `is_early_arrival` tinyint(1) NOT NULL DEFAULT 0,
  `is_undertime` tinyint(1) NOT NULL DEFAULT 0,
  `minutes_late` smallint(5) unsigned NOT NULL DEFAULT 0,
  `minutes_undertime` smallint(5) unsigned NOT NULL DEFAULT 0,
  `total_hours` decimal(5,2) DEFAULT NULL COMMENT 'Populated on time_out',
  `notes` varchar(255) DEFAULT NULL,
  `recorded_by` char(36) DEFAULT NULL COMMENT 'user_id if manual entry',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_attendance_employee` (`employee_id`),
  KEY `idx_attendance_date` (`attendance_date`),
  KEY `idx_attendance_type` (`attendance_type`),
  KEY `idx_attendance_method` (`method`),
  CONSTRAINT `fk_att_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` VALUES ('a1000000-0000-0000-0000-000000000001','e1000000-0000-0000-0000-000000000002','2026-08-03','2026-08-03 08:26:00','time_in','manual','Kiosk','192.168.1.100',0,0,0,0,0,NULL,NULL,NULL,'2026-08-04 12:56:38'),('a1000000-0000-0000-0000-000000000002','e1000000-0000-0000-0000-000000000002','2026-08-03','2026-08-03 17:33:00','time_out','manual','Kiosk','192.168.1.100',0,0,0,0,0,NULL,NULL,NULL,'2026-08-04 12:56:38'),('a1000000-0000-0000-0000-000000000003','e1000000-0000-0000-0000-000000000002','2026-08-04','2026-08-04 08:19:00','time_in','manual','Kiosk','192.168.1.100',0,0,0,0,0,NULL,NULL,NULL,'2026-08-04 12:56:38'),('a1000000-0000-0000-0000-000000000004','e1000000-0000-0000-0000-000000000002','2026-08-04','2026-08-04 17:31:00','time_out','manual','Kiosk','192.168.1.100',0,0,0,0,0,NULL,NULL,NULL,'2026-08-04 12:56:38'),('a1000000-0000-0000-0000-000000000005','e1000000-0000-0000-0000-000000000003','2026-08-03','2026-08-03 08:26:00','time_in','manual','Kiosk','192.168.1.100',0,0,0,0,0,NULL,NULL,NULL,'2026-08-04 12:56:38'),('a1000000-0000-0000-0000-000000000006','e1000000-0000-0000-0000-000000000003','2026-08-03','2026-08-03 17:33:00','time_out','manual','Kiosk','192.168.1.100',0,0,0,0,0,NULL,NULL,NULL,'2026-08-04 12:56:38'),('a1000000-0000-0000-0000-000000000007','e1000000-0000-0000-0000-000000000003','2026-08-04','2026-08-04 08:19:00','time_in','manual','Kiosk','192.168.1.100',0,0,0,0,0,NULL,NULL,NULL,'2026-08-04 12:56:38'),('a1000000-0000-0000-0000-000000000008','e1000000-0000-0000-0000-000000000003','2026-08-04','2026-08-04 17:31:00','time_out','manual','Kiosk','192.168.1.100',0,0,0,0,0,NULL,NULL,NULL,'2026-08-04 12:56:38'),('e925db6c-c3a8-4773-aba8-a6a7b9673b1c','e1000000-0000-0000-0000-000000000002','2026-08-05','2026-08-05 16:03:30','time_in','manual',NULL,NULL,0,0,0,0,0,NULL,NULL,'u1000000-0000-0000-0000-000000000002','2026-08-05 16:03:30');
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance_corrections`
--

DROP TABLE IF EXISTS `attendance_corrections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendance_corrections` (
  `id` char(36) NOT NULL,
  `employee_id` char(36) NOT NULL,
  `attendance_id` char(36) DEFAULT NULL,
  `attendance_date` date NOT NULL,
  `correction_type` enum('Forgot Time In','Forgot Time Out','Incorrect Attendance','Wrong Attendance Method') NOT NULL,
  `original_time_in` datetime DEFAULT NULL,
  `original_time_out` datetime DEFAULT NULL,
  `requested_time_in` datetime DEFAULT NULL,
  `requested_time_out` datetime DEFAULT NULL,
  `reason` text NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `approved_by` char(36) DEFAULT NULL,
  `approval_date` datetime DEFAULT NULL,
  `admin_remarks` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_correction_employee` (`employee_id`),
  KEY `idx_correction_date` (`attendance_date`),
  KEY `idx_correction_status` (`status`),
  KEY `fk_correction_attendance` (`attendance_id`),
  KEY `fk_correction_approver` (`approved_by`),
  CONSTRAINT `fk_correction_approver` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_correction_attendance` FOREIGN KEY (`attendance_id`) REFERENCES `attendance` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_correction_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_corrections`
--

LOCK TABLES `attendance_corrections` WRITE;
/*!40000 ALTER TABLE `attendance_corrections` DISABLE KEYS */;
/*!40000 ALTER TABLE `attendance_corrections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance_summary`
--

DROP TABLE IF EXISTS `attendance_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendance_summary` (
  `id` char(36) NOT NULL,
  `employee_id` char(36) NOT NULL,
  `attendance_date` date NOT NULL,
  `time_in` datetime DEFAULT NULL COMMENT 'Official: earliest time_in',
  `break_out` datetime DEFAULT NULL COMMENT 'Official: earliest break_out',
  `break_in` datetime DEFAULT NULL COMMENT 'Official: latest break_in',
  `time_out` datetime DEFAULT NULL COMMENT 'Official: latest time_out',
  `overtime_in` datetime DEFAULT NULL COMMENT 'Official: earliest overtime_in',
  `overtime_out` datetime DEFAULT NULL COMMENT 'Official: latest overtime_out',
  `lunch_out` datetime DEFAULT NULL,
  `lunch_in` datetime DEFAULT NULL,
  `total_hours` decimal(5,2) DEFAULT NULL,
  `break_minutes` smallint(5) unsigned NOT NULL DEFAULT 0,
  `late_minutes` smallint(5) unsigned NOT NULL DEFAULT 0,
  `undertime_minutes` smallint(5) unsigned NOT NULL DEFAULT 0,
  `overtime_minutes` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_late` tinyint(1) NOT NULL DEFAULT 0,
  `is_absent` tinyint(1) NOT NULL DEFAULT 0,
  `is_holiday` tinyint(1) NOT NULL DEFAULT 0,
  `day_status` enum('present','absent','half_day','holiday','rest_day','leave') NOT NULL DEFAULT 'absent',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_summary_employee_date` (`employee_id`,`attendance_date`),
  KEY `idx_summary_date` (`attendance_date`),
  KEY `idx_summary_status` (`day_status`),
  CONSTRAINT `fk_summary_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_summary`
--

LOCK TABLES `attendance_summary` WRITE;
/*!40000 ALTER TABLE `attendance_summary` DISABLE KEYS */;
INSERT INTO `attendance_summary` VALUES ('053fdafe-3091-47da-8c30-fa1ea6aea926','e1000000-0000-0000-0000-000000000003','2026-08-03','2026-08-03 08:26:00',NULL,NULL,'2026-08-03 17:33:00',NULL,NULL,NULL,NULL,9.12,0,11,0,0,1,0,0,'present','2026-08-04 12:57:14','2026-08-04 12:57:14'),('58a5eb20-9b0f-4988-bc6f-f50a28b50948','e1000000-0000-0000-0000-000000000002','2026-08-03','2026-08-03 08:26:00',NULL,NULL,'2026-08-03 17:33:00',NULL,NULL,NULL,NULL,9.12,0,11,0,0,1,0,0,'present','2026-08-04 12:57:14','2026-08-04 12:57:14'),('85607e4a-923d-4d9c-9372-3abdbd7065ad','e1000000-0000-0000-0000-000000000002','2026-08-04','2026-08-04 08:19:00',NULL,NULL,'2026-08-04 17:31:00',NULL,NULL,NULL,NULL,9.20,0,4,0,0,1,0,0,'present','2026-08-04 12:57:14','2026-08-04 12:57:14'),('8f2a5f23-1301-49f2-b4dd-06882267e45f','e1000000-0000-0000-0000-000000000002','2026-08-05','2026-08-05 16:03:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,469,0,0,1,0,0,'present','2026-08-05 16:03:30','2026-08-05 16:03:30'),('f9f2c1ff-09e5-4948-91cf-3858f2456d58','e1000000-0000-0000-0000-000000000003','2026-08-04','2026-08-04 08:19:00',NULL,NULL,'2026-08-04 17:31:00',NULL,NULL,NULL,NULL,9.20,0,4,0,0,1,0,0,'present','2026-08-04 12:57:14','2026-08-04 12:57:14');
/*!40000 ALTER TABLE `attendance_summary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` char(36) DEFAULT NULL,
  `username` varchar(60) DEFAULT NULL COMMENT 'Snapshot at time of action',
  `action` varchar(100) NOT NULL,
  `module` varchar(60) NOT NULL,
  `record_id` varchar(36) DEFAULT NULL COMMENT 'Affected record UUID',
  `previous_value` longtext DEFAULT NULL,
  `new_value` longtext DEFAULT NULL,
  `computer_name` varchar(100) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(300) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_module` (`module`),
  KEY `idx_audit_action` (`action`),
  KEY `idx_audit_created` (`created_at`),
  KEY `idx_audit_record` (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,'u1000000-0000-0000-0000-000000000001','admin','EMAIL_SETTINGS_UPDATED','email',NULL,NULL,'[\"smtp_host\",\"smtp_port\",\"smtp_username\",\"smtp_encryption\",\"smtp_from_name\",\"smtp_from_email\",\"email_report_recipient\",\"email_report_cc\",\"email_report_bcc\",\"email_retry_interval\",\"email_max_retries\",\"email_report_enabled\",\"email_schedule\",\"email_timezone\",\"email_report_compress\"]','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-04 12:58:29'),(2,'u1000000-0000-0000-0000-000000000001','admin','EMAIL_SETTINGS_UPDATED','email',NULL,NULL,'[\"smtp_host\",\"smtp_port\",\"smtp_username\",\"smtp_encryption\",\"smtp_from_name\",\"smtp_from_email\",\"email_report_recipient\",\"email_report_cc\",\"email_report_bcc\",\"email_retry_interval\",\"email_max_retries\",\"email_report_enabled\",\"email_schedule\",\"email_timezone\",\"email_report_compress\"]','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-04 12:58:51'),(3,'u1000000-0000-0000-0000-000000000001','admin','LOGIN_SUCCESS','auth','u1000000-0000-0000-0000-000000000001',NULL,NULL,'IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 13:06:56'),(4,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"00:00\",\"weekly_day\":\"1\",\"monthly_day\":\"1\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":7,\"compress_backup\":1,\"include_uploads\":0}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:19:56'),(5,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"02:25\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":7,\"compress_backup\":1,\"include_uploads\":0}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:23:29'),(6,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"02:25\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/test\\/\",\"retention_count\":7,\"compress_backup\":1,\"include_uploads\":0}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:24:50'),(7,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"02:25\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":7,\"compress_backup\":1,\"include_uploads\":0}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:24:57'),(8,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"02:25\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":7,\"compress_backup\":1,\"include_uploads\":0}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:25:04'),(9,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"02:25\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":7,\"compress_backup\":1,\"include_uploads\":0}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:25:09'),(10,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"02:25\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":1,\"compress_backup\":1,\"include_uploads\":0}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:26:04'),(11,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"14:30\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":1,\"compress_backup\":1,\"include_uploads\":0}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:29:49'),(12,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"14:30\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":1,\"compress_backup\":1,\"include_uploads\":1}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:29:51'),(13,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"14:35\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":1,\"compress_backup\":1,\"include_uploads\":1}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:34:17'),(14,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"14:40\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":1,\"compress_backup\":1,\"include_uploads\":1}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:39:08'),(15,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_DELETED','backup','7714607b-27f7-4229-a00d-10895785cfec',NULL,NULL,'IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:40:58'),(16,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_DELETED','backup','60885ea3-0c4a-41ce-b0d6-0158ac1c1879',NULL,NULL,'IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:45:30'),(17,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"14:46\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":1,\"compress_backup\":1,\"include_uploads\":1}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:45:50'),(18,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_DELETED','backup','62c9fd61-134a-462e-ade7-49c460bbefd0',NULL,NULL,'IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:46:22'),(19,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"14:50\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":1,\"compress_backup\":1,\"include_uploads\":1}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:46:56'),(20,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"14:50\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":1,\"compress_backup\":1,\"include_uploads\":1}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:47:00'),(21,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_DELETED','backup','2b5a54a8-a459-4758-90d7-68a2b40cf0ca',NULL,NULL,'IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:51:13'),(22,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"14:55\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":1,\"compress_backup\":1,\"include_uploads\":1}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:51:18'),(23,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_DELETED','backup','916c149e-da57-4aa5-b888-a2a4f0a4c78a',NULL,NULL,'IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:56:20'),(24,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"15:00\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":1,\"compress_backup\":1,\"include_uploads\":1}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 14:56:30'),(25,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_DELETED','backup','ee8ac43a-e540-4da2-a09e-729ca4304ebd',NULL,NULL,'IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 15:00:47'),(26,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"15:02\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":1,\"compress_backup\":1,\"include_uploads\":1}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 15:00:53'),(27,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_DOWNLOADED','backup','9dba3d68-2feb-4853-bc1c-4a143b55eab8',NULL,NULL,'IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 15:02:37'),(28,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_DELETED','backup','9dba3d68-2feb-4853-bc1c-4a143b55eab8',NULL,NULL,'IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 15:30:35'),(29,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"15:35\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":1,\"compress_backup\":1,\"include_uploads\":1}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 15:30:45'),(30,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_DELETED','backup','50b3ba4c-e2b9-40dd-9c47-662ead6d169a',NULL,NULL,'IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 15:49:06'),(31,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"15:51\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":1,\"compress_backup\":1,\"include_uploads\":1}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 15:49:19'),(32,'u1000000-0000-0000-0000-000000000001','admin','EMPLOYEE_UPDATED','employees','e1000000-0000-0000-0000-000000000002','\"{\\\"id\\\":\\\"e1000000-0000-0000-0000-000000000002\\\",\\\"employee_number\\\":\\\"EMP001\\\",\\\"first_name\\\":\\\"Aaron\\\",\\\"middle_name\\\":null,\\\"last_name\\\":\\\"Lim\\\",\\\"suffix\\\":null,\\\"gender\\\":\\\"Male\\\",\\\"date_of_birth\\\":\\\"1995-05-15\\\",\\\"civil_status\\\":\\\"Single\\\",\\\"nationality\\\":\\\"Filipino\\\",\\\"photo\\\":null,\\\"department_id\\\":\\\"d1000000-0000-0000-0000-000000000001\\\",\\\"branch_id\\\":\\\"b1000000-0000-0000-0000-000000000001\\\",\\\"shift_id\\\":\\\"s0000000-0000-0000-0000-000000000001\\\",\\\"position\\\":\\\"Software Developer\\\",\\\"employment_status\\\":\\\"Active\\\",\\\"employment_type\\\":\\\"Regular\\\",\\\"contact_number\\\":\\\"09171234568\\\",\\\"alternate_mobile\\\":null,\\\"email\\\":\\\"aaron.lim@company.com\\\",\\\"home_address\\\":\\\"456 Tech Ave, Manila\\\",\\\"emergency_contact_name\\\":\\\"John Lim\\\",\\\"emergency_contact_number\\\":\\\"09181234568\\\",\\\"emergency_contact_relationship\\\":\\\"Father\\\",\\\"date_hired\\\":\\\"2023-01-15\\\",\\\"immediate_supervisor_id\\\":null,\\\"username\\\":\\\"alim\\\",\\\"password_hash\\\":\\\"$2y$12$yEaM\\\\\\/kCQSTgDSRFxK9khVOmvc7vlLAkw3j36UBSTXi33yyryHvvwm\\\",\\\"pin\\\":\\\"1234\\\",\\\"pin_hash\\\":\\\"$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC\\\\\\/.og\\\\\\/at2.uheWG\\\\\\/igi\\\",\\\"qr_code_value\\\":\\\"QR-EMP001-AARON-LIM\\\",\\\"rfid_value\\\":\\\"RF-0002\\\",\\\"status\\\":\\\"active\\\",\\\"created_by\\\":null,\\\"created_at\\\":\\\"2026-08-04 12:56:38\\\",\\\"updated_by\\\":null,\\\"updated_at\\\":\\\"2026-08-04 12:56:38\\\",\\\"department_name\\\":\\\"Administration\\\",\\\"branch_name\\\":\\\"Main Branch\\\",\\\"shift_name\\\":\\\"Day Shift\\\",\\\"supervisor_number\\\":null,\\\"supervisor_name\\\":null,\\\"full_name\\\":\\\"Aaron Lim\\\",\\\"user_id\\\":\\\"u1000000-0000-0000-0000-000000000002\\\",\\\"user_role_id\\\":4,\\\"user_role_name\\\":\\\"Employee\\\",\\\"user_username\\\":\\\"alim\\\",\\\"profile_picture\\\":null}\"','{\"_csrf\":\"cfd98c4d0c391dd42100c18c470f7e9fdac70abc2fcc9d21bfa990c2174f8786\",\"id\":\"e1000000-0000-0000-0000-000000000002\",\"employee_number\":\"EMP001\",\"first_name\":\"Aaron\",\"middle_name\":\"\",\"last_name\":\"Lim\",\"suffix\":\"\",\"gender\":\"Male\",\"date_of_birth\":\"1995-05-15\",\"civil_status\":\"Single\",\"nationality\":\"Filipino\",\"contact_number\":\"09171234568\",\"alternate_mobile\":\"\",\"email\":\"aaron.lim@company.com\",\"username\":\"alim\",\"password\":\"alim\",\"role_id\":\"4\",\"home_address\":\"456 Tech Ave, Manila\",\"emergency_contact_name\":\"John Lim\",\"emergency_contact_number\":\"09181234568\",\"emergency_contact_relationship\":\"Father\",\"department_id\":\"d1000000-0000-0000-0000-000000000001\",\"branch_id\":\"b1000000-0000-0000-0000-000000000001\",\"position\":\"Software Developer\",\"employment_status\":\"Active\",\"employment_type\":\"Regular\",\"date_hired\":\"2023-01-15\",\"immediate_supervisor_id\":\"\",\"shift_id\":\"s0000000-0000-0000-0000-000000000001\",\"pin\":\"\",\"rfid_value\":\"RF-0002\",\"status\":\"active\"}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 15:49:32'),(33,'u1000000-0000-0000-0000-000000000001','admin','LOGOUT','auth','u1000000-0000-0000-0000-000000000001',NULL,NULL,'IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 15:49:34'),(34,'u1000000-0000-0000-0000-000000000002','alim','LOGIN_SUCCESS','auth','u1000000-0000-0000-0000-000000000002',NULL,NULL,'IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 15:49:36'),(35,'u1000000-0000-0000-0000-000000000001','admin','LOGIN_SUCCESS','auth','u1000000-0000-0000-0000-000000000001',NULL,NULL,'IT-PC5','192.168.30.21','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','2026-08-05 15:55:23'),(36,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_DELETED','backup','cc408e14-873d-40da-a08d-baf1094a763f',NULL,NULL,'IT-PC5','192.168.30.21','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','2026-08-05 15:55:54'),(37,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"16:00\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":1,\"compress_backup\":1,\"include_uploads\":1}','IT-PC5','192.168.30.21','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','2026-08-05 15:56:05'),(38,'u1000000-0000-0000-0000-000000000002','alim','MANUAL_ATTENDANCE_REQUEST_SUBMITTED','manual_attendance','5e459d98-39b5-41c6-9015-438393cc7761',NULL,'{\"employee_id\":\"e1000000-0000-0000-0000-000000000002\",\"type\":\"time_in\",\"date\":\"2026-08-05\",\"time\":\"16:03:30\"}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 16:03:30'),(39,'u1000000-0000-0000-0000-000000000002','alim','MANUAL_ATTENDANCE_AUTO_APPROVED','manual_attendance','5e459d98-39b5-41c6-9015-438393cc7761',NULL,'{\"employee_id\":\"e1000000-0000-0000-0000-000000000002\",\"type\":\"time_in\",\"date\":\"2026-08-05\",\"time\":\"16:03:30\"}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 16:03:30'),(40,'u1000000-0000-0000-0000-000000000002','alim','LOGOUT','auth','u1000000-0000-0000-0000-000000000002',NULL,NULL,'IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 16:11:18'),(41,'u1000000-0000-0000-0000-000000000001','admin','LOGIN_SUCCESS','auth','u1000000-0000-0000-0000-000000000001',NULL,NULL,'IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 16:11:26'),(42,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_DELETED','backup','08536f65-5e16-4aaf-9561-3c40a85b5f5e',NULL,NULL,'IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 16:11:31'),(43,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"16:15\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":1,\"compress_backup\":1,\"include_uploads\":1}','IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 16:11:45'),(44,'u1000000-0000-0000-0000-000000000001','admin','LOGOUT','auth','u1000000-0000-0000-0000-000000000001',NULL,NULL,'IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 16:11:48'),(45,'u1000000-0000-0000-0000-000000000002','alim','LOGIN_SUCCESS','auth','u1000000-0000-0000-0000-000000000002',NULL,NULL,'IT-PC5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-08-05 16:11:53'),(46,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_DELETED','backup','c8f960cf-b62b-457e-9ec1-72d57ffc4935',NULL,NULL,'IT-PC5','192.168.30.21','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','2026-08-05 16:59:34'),(47,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"17:05\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":1,\"compress_backup\":1,\"include_uploads\":1}','IT-PC5','192.168.30.21','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','2026-08-05 16:59:47'),(48,'u1000000-0000-0000-0000-000000000001','admin','BACKUP_SETTINGS_UPDATED','backup_settings',NULL,NULL,'{\"enabled\":1,\"frequency\":\"monthly\",\"backup_time\":\"17:05\",\"weekly_day\":\"1\",\"monthly_day\":\"5\",\"backup_directory\":\"\\/storage\\/backups\\/\",\"retention_count\":1,\"compress_backup\":1,\"include_uploads\":1}','IT-PC5','192.168.30.21','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','2026-08-05 17:02:55');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_logs`
--

DROP TABLE IF EXISTS `backup_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_logs` (
  `id` char(36) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `filepath` varchar(500) NOT NULL,
  `filesize` bigint(20) unsigned NOT NULL DEFAULT 0,
  `backup_type` enum('daily','weekly','monthly','manual') NOT NULL DEFAULT 'manual',
  `trigger_type` enum('automatic','manual') NOT NULL DEFAULT 'manual',
  `uploads_included` tinyint(1) NOT NULL DEFAULT 0,
  `compression_used` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('success','failed','in_progress') NOT NULL DEFAULT 'in_progress',
  `duration_seconds` smallint(5) unsigned DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` char(36) DEFAULT NULL COMMENT 'NULL = cron job',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_backup_type` (`backup_type`),
  KEY `idx_backup_status` (`status`),
  KEY `idx_backup_created` (`created_at`),
  KEY `fk_backup_user` (`created_by`),
  CONSTRAINT `fk_backup_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_logs`
--

LOCK TABLES `backup_logs` WRITE;
/*!40000 ALTER TABLE `backup_logs` DISABLE KEYS */;
INSERT INTO `backup_logs` VALUES ('d64fb70d-4f50-4448-bc2d-77afc7b81f70','','',0,'monthly','automatic',0,0,'in_progress',NULL,NULL,0,NULL,'2026-08-13 10:54:46');
/*!40000 ALTER TABLE `backup_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_schedules`
--

DROP TABLE IF EXISTS `backup_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_schedules` (
  `id` char(36) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `frequency` enum('daily','weekly','monthly') NOT NULL DEFAULT 'daily',
  `backup_time` time NOT NULL DEFAULT '00:00:00',
  `weekly_day` tinyint(4) DEFAULT NULL COMMENT '0=Sunday, 1=Monday, ..., 6=Saturday',
  `monthly_day` tinyint(4) DEFAULT NULL COMMENT '1-31, NULL for last day of month',
  `backup_directory` varchar(500) NOT NULL DEFAULT '/storage/backups/',
  `retention_count` smallint(5) unsigned NOT NULL DEFAULT 7 COMMENT 'Number of backups to keep',
  `compress_backup` tinyint(1) NOT NULL DEFAULT 1,
  `include_uploads` tinyint(1) NOT NULL DEFAULT 0,
  `last_run_at` datetime DEFAULT NULL,
  `next_run_at` datetime DEFAULT NULL,
  `last_success_at` datetime DEFAULT NULL,
  `last_failure_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_backup_schedule` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_schedules`
--

LOCK TABLES `backup_schedules` WRITE;
/*!40000 ALTER TABLE `backup_schedules` DISABLE KEYS */;
INSERT INTO `backup_schedules` VALUES ('s0000000-0000-0000-0000-000000000001',1,'monthly','17:05:00',NULL,5,'/storage/backups/',1,1,1,'2026-08-05 16:57:49','2026-08-05 17:05:00','2026-08-05 16:57:49','2026-08-05 14:35:30','2026-08-05 14:13:10','2026-08-05 17:02:55');
/*!40000 ALTER TABLE `backup_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branches` (
  `id` char(36) NOT NULL,
  `name` varchar(120) NOT NULL,
  `code` varchar(20) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `branch_manager` varchar(120) DEFAULT NULL,
  `time_zone` varchar(50) DEFAULT 'Asia/Manila',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_branches_code` (`code`),
  UNIQUE KEY `uq_branches_name` (`name`),
  KEY `idx_branches_status` (`status`),
  KEY `idx_branches_manager` (`branch_manager`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
INSERT INTO `branches` VALUES ('b1000000-0000-0000-0000-000000000001','Main Branch','MAIN','123 Main Street, City','Manila','Metro Manila','(02) 8123-4567','main@company.com',NULL,'Asia/Manila','active','2026-08-04 12:56:31','2026-08-04 12:56:31');
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `id` char(36) NOT NULL,
  `branch_id` char(36) DEFAULT NULL,
  `name` varchar(120) NOT NULL,
  `code` varchar(20) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `department_head` varchar(120) DEFAULT NULL,
  `contact_number` varchar(30) DEFAULT NULL,
  `email_address` varchar(120) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_departments_name` (`name`),
  UNIQUE KEY `uq_departments_code` (`code`),
  KEY `idx_departments_branch` (`branch_id`),
  KEY `idx_departments_status` (`status`),
  KEY `idx_departments_head` (`department_head`),
  CONSTRAINT `fk_dept_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES ('d1000000-0000-0000-0000-000000000001','b1000000-0000-0000-0000-000000000001','Administration','ADMIN','Administration Department',NULL,'(02) 8123-4567','admin@company.com','Main Building, 2nd Floor','active','2026-08-04 12:56:31','2026-08-04 12:56:31');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_logs`
--

DROP TABLE IF EXISTS `email_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_logs` (
  `id` char(36) NOT NULL,
  `recipient` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `report_period` varchar(80) DEFAULT NULL COMMENT 'e.g. June 2026',
  `body_preview` text DEFAULT NULL,
  `attachment_path` varchar(500) DEFAULT NULL,
  `status` enum('sent','failed','queued','retrying') NOT NULL DEFAULT 'queued',
  `retry_count` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `is_test_run` tinyint(1) NOT NULL DEFAULT 0,
  `simulated_date` date DEFAULT NULL,
  `report_date_from` date DEFAULT NULL COMMENT 'Period start — used to regenerate attachment on retry',
  `report_date_to` date DEFAULT NULL COMMENT 'Period end — used to regenerate attachment on retry',
  `last_error` text DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `next_retry_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_email_status` (`status`),
  KEY `idx_email_created` (`created_at`),
  KEY `idx_email_retry` (`next_retry_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_logs`
--

LOCK TABLES `email_logs` WRITE;
/*!40000 ALTER TABLE `email_logs` DISABLE KEYS */;
INSERT INTO `email_logs` VALUES ('3a372de3-ad9c-4001-92ff-35223ef96786','jerome.lim@ims.com.ph','IMS – Attendance Report (August 2026 1–15)','August 2026 (1–15)','\r\n\r\n\r\n\r\n\r\nAttendance Report — August 2026 1–15\r\n\r\n  body      { font-family: Arial, sans-serif; font-size: 14px; color: #111827; margin: 0; padding: 24px; background: #f9fafb; }\r\n  .card     { background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 28px 32px; max-width: 620px; margin: 0 auto; }\r\n  .meta     { margin: 0 0 20px; border-collapse: collapse; width: 100%; }\r\n  .meta td  { padding: 5px 0; vertical-align: top; }\r\n  .meta .lbl{ color: #6b7280; width: 160px; font-siz','C:\\Users\\AARONL~1.IMS\\AppData\\Local\\Temp\\ams_reports\\Attendance_Report_2026-08_01-15.xlsx','sent',0,0,NULL,'2026-08-01','2026-08-15',NULL,'2026-08-04 12:59:13','2026-08-04 12:59:09','2026-08-04 12:59:09','2026-08-04 12:59:13'),('770367f2-c30d-450e-a342-aa6ac77a8045','jerome.lim@ims.com.ph','IMS – Attendance Report (August 2026 1–15)','August 2026 (1–15)','Trigger: 16th of the month — First-half report (1–15) [simulated] | TZ: Asia/Manila | Date: 2026-08-16 | TEST RUN',NULL,'sent',0,1,'2026-08-16',NULL,NULL,NULL,'2026-08-04 12:59:13',NULL,'2026-08-04 12:59:13','2026-08-04 12:59:13');
/*!40000 ALTER TABLE `email_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_imports`
--

DROP TABLE IF EXISTS `employee_imports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_imports` (
  `id` char(36) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `total_rows` int(10) unsigned NOT NULL DEFAULT 0,
  `success_count` int(10) unsigned NOT NULL DEFAULT 0,
  `failed_count` int(10) unsigned NOT NULL DEFAULT 0,
  `error_report` longtext DEFAULT NULL,
  `imported_by` char(36) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_imports_created_by` (`imported_by`),
  KEY `idx_imports_created` (`created_at`),
  CONSTRAINT `fk_imports_created_by` FOREIGN KEY (`imported_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_imports`
--

LOCK TABLES `employee_imports` WRITE;
/*!40000 ALTER TABLE `employee_imports` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_imports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_timeline`
--

DROP TABLE IF EXISTS `employee_timeline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_timeline` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` char(36) NOT NULL,
  `event_type` enum('employee_created','employee_updated','employee_archived','employee_restored','employee_activated','employee_deactivated','account_created','account_updated','account_deleted','role_changed','password_changed','profile_picture_updated','status_changed','department_changed','branch_changed','shift_changed','position_changed','photo_updated','qr_code_regenerated','imported','attendance_milestone') NOT NULL,
  `previous_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_timeline_employee` (`employee_id`),
  KEY `idx_timeline_type` (`event_type`),
  KEY `idx_timeline_created` (`created_at`),
  KEY `fk_timeline_created_by` (`created_by`),
  CONSTRAINT `fk_timeline_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_timeline_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_timeline`
--

LOCK TABLES `employee_timeline` WRITE;
/*!40000 ALTER TABLE `employee_timeline` DISABLE KEYS */;
INSERT INTO `employee_timeline` VALUES (1,'e1000000-0000-0000-0000-000000000002','role_changed','{\"id\":\"e1000000-0000-0000-0000-000000000002\",\"employee_number\":\"EMP001\",\"first_name\":\"Aaron\",\"middle_name\":null,\"last_name\":\"Lim\",\"suffix\":null,\"gender\":\"Male\",\"date_of_birth\":\"1995-05-15\",\"civil_status\":\"Single\",\"nationality\":\"Filipino\",\"photo\":null,\"department_id\":\"d1000000-0000-0000-0000-000000000001\",\"branch_id\":\"b1000000-0000-0000-0000-000000000001\",\"shift_id\":\"s0000000-0000-0000-0000-000000000001\",\"position\":\"Software Developer\",\"employment_status\":\"Active\",\"employment_type\":\"Regular\",\"contact_number\":\"09171234568\",\"alternate_mobile\":null,\"email\":\"aaron.lim@company.com\",\"home_address\":\"456 Tech Ave, Manila\",\"emergency_contact_name\":\"John Lim\",\"emergency_contact_number\":\"09181234568\",\"emergency_contact_relationship\":\"Father\",\"date_hired\":\"2023-01-15\",\"immediate_supervisor_id\":null,\"username\":\"alim\",\"password_hash\":\"$2y$12$yEaM\\/kCQSTgDSRFxK9khVOmvc7vlLAkw3j36UBSTXi33yyryHvvwm\",\"pin\":\"1234\",\"pin_hash\":\"$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC\\/.og\\/at2.uheWG\\/igi\",\"qr_code_value\":\"QR-EMP001-AARON-LIM\",\"rfid_value\":\"RF-0002\",\"status\":\"active\",\"created_by\":null,\"created_at\":\"2026-08-04 12:56:38\",\"updated_by\":null,\"updated_at\":\"2026-08-04 12:56:38\",\"department_name\":\"Administration\",\"branch_name\":\"Main Branch\",\"shift_name\":\"Day Shift\",\"supervisor_number\":null,\"supervisor_name\":null,\"full_name\":\"Aaron Lim\",\"user_id\":\"u1000000-0000-0000-0000-000000000002\",\"user_role_id\":4,\"user_role_name\":\"Employee\",\"user_username\":\"alim\",\"profile_picture\":null}','{\"_csrf\":\"cfd98c4d0c391dd42100c18c470f7e9fdac70abc2fcc9d21bfa990c2174f8786\",\"id\":\"e1000000-0000-0000-0000-000000000002\",\"employee_number\":\"EMP001\",\"first_name\":\"Aaron\",\"middle_name\":\"\",\"last_name\":\"Lim\",\"suffix\":\"\",\"gender\":\"Male\",\"date_of_birth\":\"1995-05-15\",\"civil_status\":\"Single\",\"nationality\":\"Filipino\",\"contact_number\":\"09171234568\",\"alternate_mobile\":\"\",\"email\":\"aaron.lim@company.com\",\"username\":\"alim\",\"password\":\"alim\",\"role_id\":\"4\",\"home_address\":\"456 Tech Ave, Manila\",\"emergency_contact_name\":\"John Lim\",\"emergency_contact_number\":\"09181234568\",\"emergency_contact_relationship\":\"Father\",\"department_id\":\"d1000000-0000-0000-0000-000000000001\",\"branch_id\":\"b1000000-0000-0000-0000-000000000001\",\"position\":\"Software Developer\",\"employment_status\":\"Active\",\"employment_type\":\"Regular\",\"date_hired\":\"2023-01-15\",\"immediate_supervisor_id\":\"\",\"shift_id\":\"s0000000-0000-0000-0000-000000000001\",\"pin\":\"\",\"rfid_value\":\"RF-0002\",\"status\":\"active\"}','Role changed','u1000000-0000-0000-0000-000000000001','2026-08-05 15:49:32'),(2,'e1000000-0000-0000-0000-000000000002','employee_updated','{\"id\":\"e1000000-0000-0000-0000-000000000002\",\"employee_number\":\"EMP001\",\"first_name\":\"Aaron\",\"middle_name\":null,\"last_name\":\"Lim\",\"suffix\":null,\"gender\":\"Male\",\"date_of_birth\":\"1995-05-15\",\"civil_status\":\"Single\",\"nationality\":\"Filipino\",\"photo\":null,\"department_id\":\"d1000000-0000-0000-0000-000000000001\",\"branch_id\":\"b1000000-0000-0000-0000-000000000001\",\"shift_id\":\"s0000000-0000-0000-0000-000000000001\",\"position\":\"Software Developer\",\"employment_status\":\"Active\",\"employment_type\":\"Regular\",\"contact_number\":\"09171234568\",\"alternate_mobile\":null,\"email\":\"aaron.lim@company.com\",\"home_address\":\"456 Tech Ave, Manila\",\"emergency_contact_name\":\"John Lim\",\"emergency_contact_number\":\"09181234568\",\"emergency_contact_relationship\":\"Father\",\"date_hired\":\"2023-01-15\",\"immediate_supervisor_id\":null,\"username\":\"alim\",\"password_hash\":\"$2y$12$yEaM\\/kCQSTgDSRFxK9khVOmvc7vlLAkw3j36UBSTXi33yyryHvvwm\",\"pin\":\"1234\",\"pin_hash\":\"$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC\\/.og\\/at2.uheWG\\/igi\",\"qr_code_value\":\"QR-EMP001-AARON-LIM\",\"rfid_value\":\"RF-0002\",\"status\":\"active\",\"created_by\":null,\"created_at\":\"2026-08-04 12:56:38\",\"updated_by\":null,\"updated_at\":\"2026-08-04 12:56:38\",\"department_name\":\"Administration\",\"branch_name\":\"Main Branch\",\"shift_name\":\"Day Shift\",\"supervisor_number\":null,\"supervisor_name\":null,\"full_name\":\"Aaron Lim\",\"user_id\":\"u1000000-0000-0000-0000-000000000002\",\"user_role_id\":4,\"user_role_name\":\"Employee\",\"user_username\":\"alim\",\"profile_picture\":null}','{\"_csrf\":\"cfd98c4d0c391dd42100c18c470f7e9fdac70abc2fcc9d21bfa990c2174f8786\",\"id\":\"e1000000-0000-0000-0000-000000000002\",\"employee_number\":\"EMP001\",\"first_name\":\"Aaron\",\"middle_name\":\"\",\"last_name\":\"Lim\",\"suffix\":\"\",\"gender\":\"Male\",\"date_of_birth\":\"1995-05-15\",\"civil_status\":\"Single\",\"nationality\":\"Filipino\",\"contact_number\":\"09171234568\",\"alternate_mobile\":\"\",\"email\":\"aaron.lim@company.com\",\"username\":\"alim\",\"password\":\"alim\",\"role_id\":\"4\",\"home_address\":\"456 Tech Ave, Manila\",\"emergency_contact_name\":\"John Lim\",\"emergency_contact_number\":\"09181234568\",\"emergency_contact_relationship\":\"Father\",\"department_id\":\"d1000000-0000-0000-0000-000000000001\",\"branch_id\":\"b1000000-0000-0000-0000-000000000001\",\"position\":\"Software Developer\",\"employment_status\":\"Active\",\"employment_type\":\"Regular\",\"date_hired\":\"2023-01-15\",\"immediate_supervisor_id\":\"\",\"shift_id\":\"s0000000-0000-0000-0000-000000000001\",\"pin\":\"\",\"rfid_value\":\"RF-0002\",\"status\":\"active\"}','Employee updated','u1000000-0000-0000-0000-000000000001','2026-08-05 15:49:32');
/*!40000 ALTER TABLE `employee_timeline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` char(36) NOT NULL,
  `employee_number` varchar(30) NOT NULL,
  `first_name` varchar(80) NOT NULL,
  `middle_name` varchar(80) DEFAULT NULL,
  `last_name` varchar(80) NOT NULL,
  `suffix` varchar(10) DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `civil_status` enum('Single','Married','Widowed','Separated','Divorced') DEFAULT NULL,
  `nationality` varchar(80) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `department_id` char(36) DEFAULT NULL,
  `branch_id` char(36) DEFAULT NULL,
  `shift_id` char(36) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `employment_status` enum('Active','Inactive','Suspended','Resigned','Terminated','Retired') NOT NULL DEFAULT 'Active',
  `employment_type` enum('Regular','Probationary','Contractual','Part-Time','Temporary','Intern') DEFAULT 'Probationary',
  `contact_number` varchar(30) DEFAULT NULL,
  `alternate_mobile` varchar(30) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `home_address` varchar(500) DEFAULT NULL,
  `emergency_contact_name` varchar(120) DEFAULT NULL,
  `emergency_contact_number` varchar(30) DEFAULT NULL,
  `emergency_contact_relationship` varchar(50) DEFAULT NULL,
  `date_hired` date DEFAULT NULL,
  `immediate_supervisor_id` char(36) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `pin` varchar(10) DEFAULT NULL COMMENT 'Hashed PIN for attendance',
  `pin_hash` varchar(255) DEFAULT NULL,
  `qr_code_value` varchar(255) DEFAULT NULL COMMENT 'Unique QR payload',
  `rfid_value` varchar(100) DEFAULT NULL COMMENT 'RFID card number',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_by` char(36) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_by` char(36) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_employee_number` (`employee_number`),
  UNIQUE KEY `uq_employee_qr` (`qr_code_value`),
  UNIQUE KEY `uq_employee_rfid` (`rfid_value`),
  UNIQUE KEY `uq_employee_username` (`username`),
  KEY `idx_employees_department` (`department_id`),
  KEY `idx_employees_branch` (`branch_id`),
  KEY `idx_employees_shift` (`shift_id`),
  KEY `idx_employees_status` (`status`),
  KEY `idx_employees_supervisor` (`immediate_supervisor_id`),
  KEY `idx_employees_username` (`username`),
  KEY `idx_employees_name` (`last_name`,`first_name`),
  KEY `fk_emp_created_by` (`created_by`),
  KEY `fk_emp_updated_by` (`updated_by`),
  CONSTRAINT `fk_emp_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_emp_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_emp_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_emp_shift` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_emp_supervisor` FOREIGN KEY (`immediate_supervisor_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_emp_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES ('e1000000-0000-0000-0000-000000000001','ADMIN001','System',NULL,'Administrator',NULL,'Male','1990-01-01','Single','Filipino',NULL,'d1000000-0000-0000-0000-000000000001','b1000000-0000-0000-0000-000000000001','s0000000-0000-0000-0000-000000000001','System Administrator','Active','Regular','09171234567',NULL,'admin@company.com','123 Main St, Manila','Emergency Contact','09181234567','Spouse','2020-01-01',NULL,'admin','$2y$12$yEaM/kCQSTgDSRFxK9khVOmvc7vlLAkw3j36UBSTXi33yyryHvvwm','1234','$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','QR-ADMIN001-SYSTEM-ADM','RF-0001','active',NULL,'2026-08-04 12:56:31',NULL,'2026-08-04 12:56:31'),('e1000000-0000-0000-0000-000000000002','EMP001','Aaron','','Lim','','Male','1995-05-15','Single','Filipino',NULL,'d1000000-0000-0000-0000-000000000001','b1000000-0000-0000-0000-000000000001','s0000000-0000-0000-0000-000000000001','Software Developer','Active','Regular','09171234568','','aaron.lim@company.com','456 Tech Ave, Manila','John Lim','09181234568','Father','2023-01-15',NULL,'alim','$2y$10$LBDCafcq7T3rXLb5kHu8xekabegpwvBNZcYyIAG3MkMGOX6rKkflO','1234','$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','QR-EMP001-AARON-LIM','RF-0002','active',NULL,'2026-08-04 12:56:38','u1000000-0000-0000-0000-000000000001','2026-08-05 15:49:32'),('e1000000-0000-0000-0000-000000000003','EMP002','Kyle',NULL,'Rumbaoa',NULL,'Male','1996-08-20','Single','Filipino',NULL,'d1000000-0000-0000-0000-000000000001','b1000000-0000-0000-0000-000000000001','s0000000-0000-0000-0000-000000000001','Quality Assurance','Active','Regular','09171234569',NULL,'kyle.rumbaoa@company.com','789 QA Street, Manila','Maria Rumbaoa','09181234569','Mother','2023-02-01',NULL,'krumbaoa','$2y$12$yEaM/kCQSTgDSRFxK9khVOmvc7vlLAkw3j36UBSTXi33yyryHvvwm','1234','$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','QR-EMP002-KYLE-RUM','RF-0003','active',NULL,'2026-08-04 12:56:38',NULL,'2026-08-04 12:56:38');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holidays`
--

DROP TABLE IF EXISTS `holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `holidays` (
  `id` char(36) NOT NULL,
  `name` varchar(120) NOT NULL,
  `holiday_date` date NOT NULL,
  `branch_id` char(36) DEFAULT NULL,
  `type` enum('regular','special','company','branch') NOT NULL DEFAULT 'regular',
  `description` varchar(255) DEFAULT NULL,
  `is_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_holidays_date_name` (`holiday_date`,`name`),
  KEY `idx_holidays_date` (`holiday_date`),
  KEY `idx_holidays_branch` (`branch_id`),
  KEY `idx_holidays_status` (`status`),
  CONSTRAINT `fk_holiday_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holidays`
--

LOCK TABLES `holidays` WRITE;
/*!40000 ALTER TABLE `holidays` DISABLE KEYS */;
/*!40000 ALTER TABLE `holidays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_logs`
--

DROP TABLE IF EXISTS `job_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `job_name` varchar(100) NOT NULL,
  `status` enum('running','success','failed') NOT NULL DEFAULT 'running',
  `output` text DEFAULT NULL,
  `error` text DEFAULT NULL,
  `started_at` datetime NOT NULL DEFAULT current_timestamp(),
  `finished_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_job_name` (`job_name`),
  KEY `idx_job_status` (`status`),
  KEY `idx_job_started` (`started_at`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_logs`
--

LOCK TABLES `job_logs` WRITE;
/*!40000 ALTER TABLE `job_logs` DISABLE KEYS */;
INSERT INTO `job_logs` VALUES (1,'backup_scheduler','success','Duration: 1s',NULL,'2026-08-05 14:40:13','2026-08-05 14:40:13'),(2,'backup_scheduler','success','Duration: 1s',NULL,'2026-08-05 14:46:14','2026-08-05 14:46:14'),(3,'backup_scheduler','success','Duration: 1s',NULL,'2026-08-05 14:51:05','2026-08-05 14:51:05'),(4,'backup_scheduler','success','Duration: 1s',NULL,'2026-08-05 14:56:16','2026-08-05 14:56:16'),(5,'backup_scheduler','success','Duration: 1s',NULL,'2026-08-05 15:00:34','2026-08-05 15:00:34'),(6,'backup_scheduler','success','Duration: 1s',NULL,'2026-08-05 15:02:32','2026-08-05 15:02:32'),(7,'backup_scheduler','success','Duration: 1s',NULL,'2026-08-05 15:42:04','2026-08-05 15:42:04'),(8,'backup_scheduler','success','Duration: 5s',NULL,'2026-08-05 15:54:54','2026-08-05 15:54:54'),(9,'backup_scheduler','success','Duration: 1s',NULL,'2026-08-05 16:03:26','2026-08-05 16:03:26'),(10,'backup_scheduler','success','Duration: 1s',NULL,'2026-08-05 16:57:49','2026-08-05 16:57:49');
/*!40000 ALTER TABLE `job_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_balances`
--

DROP TABLE IF EXISTS `leave_balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_balances` (
  `id` char(36) NOT NULL,
  `employee_id` char(36) NOT NULL,
  `leave_type` varchar(80) NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `entitled_days` decimal(6,2) NOT NULL DEFAULT 0.00,
  `used_days` decimal(6,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_leave_balance` (`employee_id`,`leave_type`,`year`),
  CONSTRAINT `fk_balance_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_balances`
--

LOCK TABLES `leave_balances` WRITE;
/*!40000 ALTER TABLE `leave_balances` DISABLE KEYS */;
/*!40000 ALTER TABLE `leave_balances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_requests`
--

DROP TABLE IF EXISTS `leave_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_requests` (
  `id` char(36) NOT NULL,
  `employee_id` char(36) NOT NULL,
  `leave_type` enum('Vacation Leave','Sick Leave','Emergency Leave','Maternity Leave','Paternity Leave','Bereavement Leave','Unpaid Leave') NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `number_of_days` decimal(6,2) NOT NULL DEFAULT 0.00,
  `reason` text NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected','Cancelled') NOT NULL DEFAULT 'Pending',
  `approved_by` char(36) DEFAULT NULL,
  `approval_date` datetime DEFAULT NULL,
  `admin_remarks` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_leave_employee` (`employee_id`),
  KEY `idx_leave_dates` (`start_date`,`end_date`),
  KEY `idx_leave_status` (`status`),
  KEY `idx_leave_type` (`leave_type`),
  KEY `fk_leave_approver` (`approved_by`),
  CONSTRAINT `fk_leave_approver` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_leave_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_requests`
--

LOCK TABLES `leave_requests` WRITE;
/*!40000 ALTER TABLE `leave_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `leave_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manual_attendance_requests`
--

DROP TABLE IF EXISTS `manual_attendance_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manual_attendance_requests` (
  `id` char(36) NOT NULL,
  `employee_id` char(36) NOT NULL,
  `request_type` enum('time_in','break_out','break_in','time_out','overtime_in','overtime_out') NOT NULL,
  `request_date` date NOT NULL,
  `requested_time` time NOT NULL,
  `reason` text NOT NULL,
  `reason_category` enum('Forgot QR Code','Forgot PIN','RFID Card Lost','Device Unavailable','Power Outage','System Maintenance','Other') NOT NULL DEFAULT 'Other',
  `status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `reviewed_by` char(36) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `admin_remarks` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_mar_employee` (`employee_id`),
  KEY `idx_mar_date` (`request_date`),
  KEY `idx_mar_status` (`status`),
  KEY `fk_mar_reviewer` (`reviewed_by`),
  CONSTRAINT `fk_mar_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mar_reviewer` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manual_attendance_requests`
--

LOCK TABLES `manual_attendance_requests` WRITE;
/*!40000 ALTER TABLE `manual_attendance_requests` DISABLE KEYS */;
INSERT INTO `manual_attendance_requests` VALUES ('5e459d98-39b5-41c6-9015-438393cc7761','e1000000-0000-0000-0000-000000000002','time_in','2026-08-05','16:03:30','Manual attendance entry','Other','Approved',NULL,'2026-08-05 16:03:30','Auto-approved: attendance recorded immediately.','2026-08-05 16:03:30','2026-08-05 16:03:30');
/*!40000 ALTER TABLE `manual_attendance_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `recipient_user_id` char(36) NOT NULL,
  `title` varchar(160) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','danger') NOT NULL DEFAULT 'info',
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_notifications_recipient` (`recipient_user_id`,`is_read`,`created_at`),
  CONSTRAINT `fk_notification_user` FOREIGN KEY (`recipient_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('0da44172-8dc1-4865-9c9f-61ea91537208','u1000000-0000-0000-0000-000000000001','Automatic Backup Completed','Backup completed successfully. Type: monthly, Size: 388.03 KB','success',0,'2026-08-05 15:02:32'),('542ab671-482e-4262-b428-3ea7ce980dfb','u1000000-0000-0000-0000-000000000001','Automatic Backup Completed','Backup completed successfully. Type: monthly, Size: 389.42 KB','success',0,'2026-08-05 15:54:54'),('5ce22fde-2b2b-48d5-92dc-b65f6b57ad4c','u1000000-0000-0000-0000-000000000001','Automatic Backup Completed','Backup completed successfully. Type: monthly, Size: 387.8 KB','success',0,'2026-08-05 14:56:16'),('5ee85a6f-b168-44da-980a-d3676d817398','u1000000-0000-0000-0000-000000000001','Automatic Backup Completed','Backup completed successfully. Type: monthly, Size: 388.17 KB','success',0,'2026-08-05 15:42:04'),('7cb33fd5-e4cc-4261-a268-bbef874509c6','u1000000-0000-0000-0000-000000000001','Automatic Backup Completed','Backup completed successfully. Type: monthly, Size: 389.63 KB','success',0,'2026-08-05 16:03:26'),('8267879f-042d-481a-be83-591d0f53def7','u1000000-0000-0000-0000-000000000001','Automatic Backup Completed','Backup completed successfully. Type: monthly, Size: 390.24 KB','success',0,'2026-08-05 16:57:49'),('8ccd4978-c529-4114-aaac-2901092d7717','u1000000-0000-0000-0000-000000000001','Automatic Backup Completed','Backup completed successfully. Type: monthly, Size: 387.63 KB','success',0,'2026-08-05 14:51:05'),('c6cf1f0d-33cd-43da-9dab-92581e1a0e3f','u1000000-0000-0000-0000-000000000001','Manual Attendance Recorded','Aaron Lim recorded a manual Time In for 2026-08-05.','info',0,'2026-08-05 16:03:30'),('eeaf6e10-9c9c-4ad1-97ae-3ac578035aed','u1000000-0000-0000-0000-000000000001','Automatic Backup Completed','Backup completed successfully. Type: monthly, Size: 387.91 KB','success',0,'2026-08-05 15:00:34');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `module` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_permissions_slug` (`slug`),
  KEY `idx_permissions_module` (`module`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'View Dashboard','dashboard.view','dashboard','Access dashboard','2026-08-04 12:56:31'),(2,'View Users','users.view','users','View user list','2026-08-04 12:56:31'),(3,'Create Users','users.create','users','Add new user','2026-08-04 12:56:31'),(4,'Edit Users','users.edit','users','Modify user','2026-08-04 12:56:31'),(5,'Delete Users','users.delete','users','Remove user','2026-08-04 12:56:31'),(6,'View Employees','employees.view','employees','View employee list','2026-08-04 12:56:31'),(7,'Create Employees','employees.create','employees','Add employee','2026-08-04 12:56:31'),(8,'Edit Employees','employees.edit','employees','Modify employee','2026-08-04 12:56:31'),(9,'Delete Employees','employees.delete','employees','Archive/restore employees','2026-08-04 12:56:31'),(10,'Manage Employee Status','employees.status','employees','Activate/deactivate/suspend employees','2026-08-04 12:56:31'),(11,'Import Employees','employees.import','employees','Import employees from Excel','2026-08-04 12:56:31'),(12,'Export Employees','employees.export','employees','Export employee data','2026-08-04 12:56:31'),(13,'View Employee Timeline','employees.timeline','employees','View employee activity timeline','2026-08-04 12:56:31'),(14,'Manage Employee Photos','employees.photos','employees','Upload and manage employee photos','2026-08-04 12:56:31'),(15,'Regenerate QR Codes','employees.qr_regenerate','employees','Regenerate employee QR codes','2026-08-04 12:56:31'),(16,'View Departments','departments.view','departments','View departments','2026-08-04 12:56:31'),(17,'Create Departments','departments.create','departments','Add department','2026-08-04 12:56:31'),(18,'Edit Departments','departments.edit','departments','Modify department','2026-08-04 12:56:31'),(19,'View Branches','branches.view','branches','View branches','2026-08-04 12:56:31'),(20,'Create Branches','branches.create','branches','Add branch','2026-08-04 12:56:31'),(21,'Edit Branches','branches.edit','branches','Modify branch','2026-08-04 12:56:31'),(22,'View Shifts','shifts.view','shifts','View shifts','2026-08-04 12:56:31'),(23,'Create Shifts','shifts.create','shifts','Add shift','2026-08-04 12:56:31'),(24,'Edit Shifts','shifts.edit','shifts','Modify shift','2026-08-04 12:56:31'),(25,'Delete Shifts','shifts.delete','shifts','Delete shift','2026-08-04 12:56:31'),(26,'View All Attendance','attendance.view_all','attendance','View any employee attendance','2026-08-04 12:56:31'),(27,'View Own Attendance','attendance.view_own','attendance','View own attendance only','2026-08-04 12:56:31'),(28,'Record Attendance','attendance.record','attendance','Record attendance entry','2026-08-04 12:56:31'),(29,'Edit Attendance','attendance.edit','attendance','Modify attendance records','2026-08-04 12:56:31'),(30,'View Attendance Monitoring','attendance.monitor','attendance','Access attendance monitoring','2026-08-04 12:56:31'),(31,'Manage Manual Attendance','manual_attendance.manage','manual_attendance','Admin: create manual attendance records','2026-08-04 12:56:31'),(32,'Request Manual Attendance','manual_attendance.request','manual_attendance','Employee: submit manual time-in/out requests','2026-08-04 12:56:31'),(33,'Approve Manual Attendance','manual_attendance.approve','manual_attendance','Admin: approve/reject manual attendance requests','2026-08-04 12:56:31'),(34,'Manage Leave Requests','leaves.manage','leaves','Approve, reject, cancel and search leave requests','2026-08-04 12:56:31'),(35,'Create Own Leave Requests','leaves.create_own','leaves','Submit own leave requests','2026-08-04 12:56:31'),(36,'Manage Corrections','corrections.manage','corrections','Review attendance correction requests','2026-08-04 12:56:31'),(37,'Create Own Corrections','corrections.create_own','corrections','Submit attendance corrections','2026-08-04 12:56:31'),(38,'Manage Holidays','holidays.manage','holidays','Create, edit and deactivate holidays','2026-08-04 12:56:31'),(39,'View Notifications','notifications.view','notifications','View internal notifications','2026-08-04 12:56:31'),(40,'Manage Announcements','announcements.manage','announcements','Create and manage announcements','2026-08-04 12:56:31'),(41,'View Announcements','announcements.view','announcements','View announcements on dashboard','2026-08-04 12:56:31'),(42,'View Audit Logs','audit.view','audit','Access audit trail','2026-08-04 12:56:31'),(43,'View Reports','reports.view','reports','Access reports','2026-08-04 12:56:31'),(44,'Use Global Search','search.use','search','Use reusable global search','2026-08-04 12:56:31'),(45,'Manage Settings','settings.manage','settings','Edit system settings','2026-08-04 12:56:31'),(46,'Manage System Settings','system.settings','system','Change system configuration','2026-08-04 12:56:31'),(47,'View System Health','system.health','system','View system health dashboard','2026-08-04 12:56:31'),(48,'View Email Logs','email_logs.view','email','View email delivery logs','2026-08-04 12:56:31'),(49,'Manage Email Settings','email_settings.manage','email','Configure SMTP and email report settings','2026-08-04 12:56:31'),(50,'Manage Backups','backup.manage','backup','Create, download, restore and delete backups','2026-08-04 12:56:31'),(51,'View Backup Logs','backup_logs.view','backup','View backup history','2026-08-04 12:56:31'),(52,'View Job Logs','job_logs.view','system','View background job execution history','2026-08-04 12:56:31');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_permissions` (
  `role_id` tinyint(3) unsigned NOT NULL,
  `permission_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `fk_rp_permission` (`permission_id`),
  CONSTRAINT `fk_rp_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rp_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),(1,18),(1,19),(1,20),(1,21),(1,22),(1,23),(1,24),(1,25),(1,26),(1,27),(1,28),(1,29),(1,30),(1,31),(1,32),(1,33),(1,34),(1,35),(1,36),(1,37),(1,38),(1,39),(1,40),(1,41),(1,42),(1,43),(1,44),(1,45),(1,46),(1,47),(1,48),(1,49),(1,50),(1,51),(1,52),(2,1),(2,6),(2,7),(2,8),(2,9),(2,10),(2,11),(2,12),(2,13),(2,14),(2,15),(2,16),(2,17),(2,18),(2,22),(2,23),(2,24),(2,25),(2,26),(2,28),(2,29),(2,30),(2,31),(2,33),(2,34),(2,35),(2,36),(2,37),(2,38),(2,39),(2,40),(2,41),(2,43),(2,44),(2,45),(3,1),(3,6),(3,26),(3,30),(3,33),(3,34),(3,36),(3,39),(3,41),(3,44),(4,1),(4,27),(4,32),(4,35),(4,37),(4,39),(4,41),(4,44);
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_roles_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrator','administrator','Full system access','2026-08-04 12:56:31'),(2,'HR','hr','Human Resources - employee and attendance management','2026-08-04 12:56:31'),(3,'Supervisor','supervisor','Department supervisor - can view team attendance','2026-08-04 12:56:31'),(4,'Employee','employee','Can view own attendance only','2026-08-04 12:56:31');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(80) NOT NULL,
  `value` text DEFAULT NULL,
  `type` enum('string','integer','boolean','json') NOT NULL DEFAULT 'string',
  `group` varchar(50) NOT NULL DEFAULT 'general',
  `description` varchar(255) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_settings_key` (`key`),
  KEY `idx_settings_group` (`group`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'app_name','Integrated Management Services, Inc.','string','general','Application name','2026-08-04 12:56:31'),(2,'app_version','1.0.0','string','general','Application version','2026-08-04 12:56:31'),(3,'branch_name','Main Branch','string','general','Current branch name','2026-08-04 12:56:31'),(4,'branch_id','b1000000-0000-0000-0000-000000000001','string','general','Current branch UUID','2026-08-04 12:56:31'),(5,'company_name','My Company','string','company','Company name','2026-08-04 12:56:31'),(6,'company_abbreviation','IMS','string','company','Company abbreviation (short name)','2026-08-04 12:56:31'),(7,'company_logo','','string','company','Logo path relative to public/','2026-08-04 12:56:31'),(8,'timezone','Asia/Manila','string','system','System timezone','2026-08-04 12:56:31'),(9,'grace_period_minutes','15','integer','attendance','Grace period in minutes before marking late','2026-08-04 12:56:31'),(10,'work_hours_per_day','8','','attendance','Standard working hours per day','2026-08-04 12:56:31'),(11,'overtime_threshold','30','integer','attendance','Minutes after shift end before counting overtime','2026-08-04 12:56:31'),(12,'late_deduction','1','boolean','attendance','Deduct late minutes from salary','2026-08-04 12:56:31'),(13,'allowed_time_in_from','06:00','','attendance','Earliest allowed time-in','2026-08-04 12:56:31'),(14,'allowed_time_in_to','10:00','','attendance','Latest allowed time-in (warn if exceeded)','2026-08-04 12:56:31'),(15,'method_pin','1','boolean','attendance','Enable PIN attendance method','2026-08-04 12:56:31'),(16,'method_qr','1','boolean','attendance','Enable QR Code attendance method','2026-08-04 12:56:31'),(17,'method_rfid','1','boolean','attendance','Enable RFID attendance method','2026-08-04 12:56:31'),(18,'method_manual','1','boolean','attendance','Enable Manual attendance method','2026-08-04 12:56:31'),(19,'attendance_kiosk_mode','1','boolean','attendance','Enable kiosk mode (no login required)','2026-08-04 12:56:31'),(20,'pin_length','4','integer','attendance','Default PIN length','2026-08-04 12:56:31'),(21,'allow_manual_entry','1','boolean','attendance','Allow HR/Admin to manually add attendance','2026-08-04 12:56:31'),(22,'exclude_weekends_from_leave','1','boolean','leave','Exclude Saturdays and Sundays from leave day calculation','2026-08-04 12:56:31'),(23,'backup_enabled','1','boolean','backup','Enable automatic backups','2026-08-04 12:56:31'),(24,'backup_daily','1','boolean','backup','Run daily backup','2026-08-04 12:56:31'),(25,'backup_weekly','1','boolean','backup','Run weekly backup','2026-08-04 12:56:31'),(26,'backup_monthly','1','boolean','backup','Run monthly backup','2026-08-04 12:56:31'),(27,'backup_retention_days','30','integer','backup','Days to keep old backups','2026-08-04 12:56:31'),(28,'backup_compress','1','boolean','backup','Compress backups with gzip/zip','2026-08-04 12:56:31'),(29,'backup_path','','string','backup','Absolute path to backup directory (blank = auto)','2026-08-04 12:56:31'),(30,'smtp_host','proverbs.ims.com.ph','string','email','SMTP server hostname','2026-08-04 12:58:51'),(31,'smtp_port','587','integer','email','SMTP port','2026-08-04 12:58:51'),(32,'smtp_username','jerome.lim@ims.com.ph','string','email','SMTP username','2026-08-04 12:58:51'),(33,'smtp_password','TftW0MVzPTgRr6hwDxIUHlpla3U1TFplNm1NYjZ0VXZlZ1MzTEE9PQ==','string','email','SMTP password (stored encrypted)','2026-08-04 12:58:29'),(34,'smtp_encryption','tls','string','email','Encryption: tls or ssl','2026-08-04 12:58:51'),(35,'smtp_from_name','Davao Attendance System','string','email','Sender display name','2026-08-04 12:58:51'),(36,'smtp_from_email','jerome.lim@ims.com.ph','string','email','Sender email address','2026-08-04 12:58:51'),(37,'email_report_recipient','jerome.lim@ims.com.ph','string','email','Primary report recipient email','2026-08-04 12:58:51'),(38,'email_report_cc','noel.ceniza@ims.com.ph','string','email','CC addresses (comma-separated)','2026-08-04 12:58:51'),(39,'email_report_bcc','','string','email','BCC addresses (comma-separated)','2026-08-04 12:58:51'),(40,'email_retry_interval','60','integer','email','Minutes between retry attempts','2026-08-04 12:58:51'),(41,'email_max_retries','5','integer','email','Maximum retry attempts before giving up','2026-08-04 12:58:51'),(42,'email_report_enabled','1','boolean','email','Enable automatic monthly email reports','2026-08-04 12:58:51'),(43,'email_report_compress','0','boolean','email','Compress report attachments into ZIP','2026-08-04 12:58:51'),(44,'email_schedule','both','string','email','Email schedule: manual, 15th, end_of_month, or both','2026-08-04 12:58:51'),(45,'email_timezone','Asia/Manila','string','email','Timezone for email scheduling (e.g., Asia/Manila, America/New_York)','2026-08-04 12:58:51'),(46,'last_email_sent_date',NULL,'string','email','Last date when scheduled email was sent (YYYY-MM-DD)','2026-08-04 12:56:31'),(47,'log_retention_days','90','integer','maintenance','Days to retain audit and system logs','2026-08-04 12:56:31'),(48,'session_cleanup_days','7','integer','maintenance','Days to retain expired sessions','2026-08-04 12:56:31'),(49,'archive_after_months','12','integer','maintenance','Months before archiving old attendance records','2026-08-04 12:56:31'),(50,'photo_max_size_kb','2048','integer','upload','Maximum photo size in KB','2026-08-04 12:56:31'),(51,'pagination_limit','25','integer','ui','Records per page','2026-08-04 12:56:31'),(52,'employee_photo_max_size','2097152','integer','employees','Maximum employee photo size in bytes (2MB)','2026-08-04 12:56:31'),(53,'employee_photo_allowed_types','jpg,jpeg,png','string','employees','Allowed employee photo file types','2026-08-04 12:56:31'),(54,'qr_code_size','300','integer','employees','QR code image size in pixels','2026-08-04 12:56:31'),(55,'qr_code_error_correction','M','string','employees','QR code error correction level (L, M, Q, H)','2026-08-04 12:56:31');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shifts`
--

DROP TABLE IF EXISTS `shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shifts` (
  `id` char(36) NOT NULL,
  `name` varchar(80) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('regular','night','flexible') NOT NULL DEFAULT 'regular',
  `time_in` time NOT NULL,
  `time_out` time NOT NULL,
  `lunch_break_start` time DEFAULT NULL,
  `lunch_break_end` time DEFAULT NULL,
  `lunch_break_minutes` tinyint(3) unsigned NOT NULL DEFAULT 60,
  `grace_period_minutes` tinyint(3) unsigned NOT NULL DEFAULT 15,
  `required_hours` decimal(4,2) NOT NULL DEFAULT 8.00,
  `overnight` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 = time_out is next day',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `is_default` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 = auto-assigned to new employees',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_shifts_status` (`status`),
  KEY `idx_shifts_default` (`is_default`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shifts`
--

LOCK TABLES `shifts` WRITE;
/*!40000 ALTER TABLE `shifts` DISABLE KEYS */;
INSERT INTO `shifts` VALUES ('s0000000-0000-0000-0000-000000000001','Day Shift','Standard 8 AM – 5 PM office shift with a 1-hour lunch break.','regular','08:00:00','17:00:00','12:00:00','13:00:00',60,15,8.00,0,'active',1,'2026-08-04 12:56:31','2026-08-04 12:56:31');
/*!40000 ALTER TABLE `shifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_sessions`
--

DROP TABLE IF EXISTS `user_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_sessions` (
  `id` varchar(128) NOT NULL,
  `user_id` char(36) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(300) DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sessions_user` (`user_id`),
  KEY `idx_sessions_activity` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_sessions`
--

LOCK TABLES `user_sessions` WRITE;
/*!40000 ALTER TABLE `user_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` char(36) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role_id` tinyint(3) unsigned NOT NULL,
  `employee_id` char(36) DEFAULT NULL,
  `full_name` varchar(180) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `status` enum('active','inactive','locked') NOT NULL DEFAULT 'active',
  `failed_attempts` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `password_changed_at` datetime DEFAULT NULL,
  `must_change_password` tinyint(1) NOT NULL DEFAULT 0,
  `profile_picture` varchar(255) DEFAULT NULL COMMENT 'Relative path under uploads/avatars/',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_username` (`username`),
  UNIQUE KEY `uq_users_employee` (`employee_id`),
  KEY `idx_users_role` (`role_id`),
  KEY `idx_users_status` (`status`),
  CONSTRAINT `fk_user_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_user_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('u1000000-0000-0000-0000-000000000001','admin','$2y$12$yEaM/kCQSTgDSRFxK9khVOmvc7vlLAkw3j36UBSTXi33yyryHvvwm',1,'e1000000-0000-0000-0000-000000000001','System Administrator','admin@company.com','active',0,NULL,'2026-08-05 16:11:26','::1','2026-08-04 12:56:31',0,NULL,'2026-08-04 12:56:31','2026-08-05 16:11:26'),('u1000000-0000-0000-0000-000000000002','alim','$2y$10$LBDCafcq7T3rXLb5kHu8xekabegpwvBNZcYyIAG3MkMGOX6rKkflO',4,'e1000000-0000-0000-0000-000000000002','Aaron Lim','aaron.lim@company.com','active',0,NULL,'2026-08-05 16:11:53','::1','2026-08-04 12:56:38',0,NULL,'2026-08-04 12:56:38','2026-08-05 16:11:53'),('u1000000-0000-0000-0000-000000000003','krumbaoa','$2y$12$yEaM/kCQSTgDSRFxK9khVOmvc7vlLAkw3j36UBSTXi33yyryHvvwm',4,'e1000000-0000-0000-0000-000000000003','Kyle Rumbaoa','kyle.rumbaoa@company.com','active',0,NULL,NULL,NULL,'2026-08-04 12:56:38',0,NULL,'2026-08-04 12:56:38','2026-08-04 12:56:38');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'attendance_db'
--

--
-- Dumping routines for database 'attendance_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-13 10:54:47
